﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    //Teacher类实现教师接口,并宣布考试开始。
    class Teacher : ITeacherInterface
    {
        //显示接口实现，只能通过接口引用访问
        void ITeacherInterface.HomeworkAssignment(int chapter)
        {
            switch (chapter)
            {
                case 1:
                    Console.WriteLine("Please complete chapter : {0}", chapter);
                    break;
                case 2:
                    Console.WriteLine("Please complete chapter : {0}", chapter);
                    break;
                default:
                    Console.WriteLine("Please review your lessons.");
                    break;
            }
        }
        //创建事件并发布  delegate void StudentSum();
        public event StudentSum StudentNumber;
        public void Sum(int sum)
        {
            if (sum == 20 && StudentNumber != null)
            {
                StudentNumber();
            }
        }
    }
}
