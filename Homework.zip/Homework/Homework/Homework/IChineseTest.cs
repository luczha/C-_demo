﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    //定义语文测试接口继承语文接口
    interface IChineseTest : IChinese
    {

    }
}
