﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    //声明三个接口，便于实现继承多个接口，其中，IChinese, IMath具有相同的成员函数
    public interface IChinese
    {
        void HomeworkRequirement(string subjectName);
    }
}
