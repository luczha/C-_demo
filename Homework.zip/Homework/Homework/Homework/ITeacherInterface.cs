﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    //声明一个教师接口，负责布置作业内容。
    public interface ITeacherInterface
    {
        //布置作业，根据所学章节去完成相应的作业。
        void HomeworkAssignment(int chapter);
    }
}
