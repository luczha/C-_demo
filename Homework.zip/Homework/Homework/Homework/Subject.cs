﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
         //定义学科类实现IChinese, IMath, IEnglish三个接口。
    class Subject : IChinese, IMath, IEnglish
    {
        public void HomeworkRequirement(string subjectName)
        {
            Console.WriteLine("Subject: This is the requirement of {0}.", subjectName);
        }
        public void EnglishHomeworkRequirement(string subjectName)
        {
            Console.WriteLine("Subject: This is the requirement of english.");
        }
    }
}
