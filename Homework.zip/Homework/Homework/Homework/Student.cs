﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    class Student
    {
        //记录每题分数
        public int examinationScore()
        {
            return 90;
        }
        //记录总分
        public int totalScore()
        {
            return 80;
        }
        //显示学生学号,并对已有学号进行处理
        public void studentId1(ref int id)
        {
            id += 2;
        }
        public void studentId2(ref int id)
        {
            id += 3;
        }

        //学生订阅事件
        public int studentNumber
        {
            get;
            private set;
        }
        public Student()
        {

        }
        public Student(Teacher teacher)
        {
            studentNumber = 0;
            teacher.StudentNumber += StudentTotal;
        }

        void StudentTotal()
        {
            studentNumber++;
            Console.WriteLine("All students are here,exam starts.");
        }
    }
}
