﻿using System;

namespace Homework
{
    //声明返回值为空的委托类型
    delegate void MyDel(string str);
    //声明返回值为int的委托类型,用来记录分数
    delegate int Score();
    //声明返回值为void的委托类型，用来记录学号
    delegate void StudentId(ref int id);
    //声明返回值为int的委托类型，用来显示本场考试人数
    delegate int StudentNumber(int number);
    //声明委托，用于计算班级考生到场人数
    delegate void StudentSum();

    class Program
    {
        static void Main(string[] args)
        {
            Teacher teacher = new Teacher();
            //将Teacher的对象强制转换为ITeacherInterface接口的引用。
            ITeacherInterface ITeacher1 = (ITeacherInterface)teacher;
            //显示接口实现，只能用接口引用访问
            //chapter 1作业
            ITeacher1.HomeworkAssignment(1);
            //使用as获取接口引用。
            ITeacherInterface ITeacher2 = teacher as ITeacherInterface; 
            if (ITeacher2 != null)
            {
                //chapter2作业
                ITeacher2.HomeworkAssignment(2);
            }
            //多个接口的引用
            Subject chinese = new Subject();
            Subject math = new Subject();
            Subject english = new Subject();
            IChinese Ichinese = (IChinese)chinese;
            IMath Imath = (IMath)math;
            IEnglish Ienglish = (IEnglish)english;
            Ichinese.HomeworkRequirement("chinese");
            Imath.HomeworkRequirement("math");
            Ienglish.EnglishHomeworkRequirement("english");
            
            //声明Chinese的对象
            Chinese chinese1 = new Chinese();
            chinese1.HomeworkRequirement("chinese1");
            
            //声明语文测试对象
            TestChinese testChinese = new TestChinese();
            testChinese.HomeworkRequirement("Hello,weclome to ChineseTest");

            //声明一个委托变量并用来显示
            MyDel del1 = new MyDel(testChinese.HomeworkRequirement);
            del1("Today is Chinese Test!");
            //使用快捷语法
            MyDel del2 = testChinese.HomeworkRequirement;
            del2("Today is Math Test!");
            //声明并使用组合委托
            MyDel del3 = del1 + del2;
            del3("Today is English Test!");
            //将方法chinese1.EnglishHomeworkRequirement添加到del3中。
            del3 += chinese1.HomeworkRequirement;
            del3("Enjoy your test!");

            //将方法chinese1.EnglishHomeworkRequirement从del3中移除。
            del3 -= chinese1.HomeworkRequirement;
            del3("Test is dismiss!");


            //声明一个StudentScore对象.
            Student student = new Student();
            Score score = student.examinationScore;
            score += student.totalScore;
            Console.WriteLine("totalScore is : {0}", score());

            //声明学号变量
            StudentId id = student.studentId1;
            id += student.studentId2;
            int x = 5;
            id(ref x);
            Console.WriteLine("studentId is : {0}", x);
            //匿名方法,用在初始化或只有一次调用时
            StudentNumber studentNumber1 = delegate (int number)
                                          {
                                              //使用外部变量x，此时应为50 + 10
                                              return number + x;
                                          };
            Console.WriteLine("studentNumber is : {0}", studentNumber1(50));
            //使用Lambda表达式显示学生总人数
            StudentNumber studentNumber2 = (int number2) => {return number2 + x;};
            Console.WriteLine("Lambda: studentNumber is : {0}", studentNumber2(60));

            StudentNumber studentNumber3 = (number3) => {return number3 + x; };
            Console.WriteLine("Lambda: studentNumber is : {0}", studentNumber3(70));

            StudentNumber studentNumber4 = number4 => {return number4 + x; };
            Console.WriteLine("Lambda: studentNumber is : {0}", studentNumber4(80));

            StudentNumber studentNumber5 = number5 => number5 + x;
            Console.WriteLine("Lambda: studentNumber is : {0}", studentNumber5(90));
            //事件测试
            Teacher teacher2 = new Teacher();
            Student student2 = new Student(teacher2);
            teacher2.Sum(20);
        }
    }
}
