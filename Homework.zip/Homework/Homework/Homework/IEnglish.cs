﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    public interface IEnglish
    {
        void EnglishHomeworkRequirement(string subjectName);
    }
}
