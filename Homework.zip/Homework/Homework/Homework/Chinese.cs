﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    //派生自Subject的类实现IChinese接口
    class Chinese : Subject, IChinese
    {
        //空类体
    }
}
