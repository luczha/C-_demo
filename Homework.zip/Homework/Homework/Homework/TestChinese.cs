﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    //声明语文测试类，继承语文测试接口。
    class TestChinese : IChineseTest
    {
        public void HomeworkRequirement(string subjectName)
        {
            Console.WriteLine("TestChinese: This is the requirement of {0}.", subjectName);
        }
    }
}
